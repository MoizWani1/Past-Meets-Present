
export interface UploadedPhoto {
  dataUrl: string;
  file: File;
}
